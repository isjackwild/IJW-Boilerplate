var gulp = require('gulp');

gulp.task('default', ['sass', 'markup', 'php', 'watch', 'images', 'fonts']);
